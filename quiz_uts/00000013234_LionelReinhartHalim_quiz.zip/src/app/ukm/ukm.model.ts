export class UKM {
    constructor(
        public id: number,
        public name: string,
        public desc: string,
    ) {}
}
